<!--
Hi! Thank you for your PR! Please make sure you file it against
the devel branch (not master!), DON'T adjust the version number
in setup.py (that will be done on release) and make sure you
also update the README as needed.

Thanks!

PS: You may safely delete this ;)
-->
